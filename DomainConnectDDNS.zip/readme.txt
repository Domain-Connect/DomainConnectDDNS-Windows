== Installation/Use ==

We haven't created an installer yet. But installation and setup is pretty straight forward. We've packed all the
executable files into a .zip file.

=== Setup ===

Run DomainConnectDDNSSetup.exe. This program will prompt you for a domain name and an optional host. 

After entering, it will determine if your domain supports Domain Connect. If it does, you will be prompted
to authorize the application access to DNS for your domain.

After authorization copy and paste the code into the setup dialog, and click Finish.

=== Installing and Running the Service ===

To install the service, you need to run a cmd prompt as the System Administrator.  Visit the directory
where you unpacked the files, and run the command:

c:\windows\Microsoft.Net\Framework\v4.0.30319\InstallUtil.exe DomainConnectDDNSUpdate.exe

This will install the service instance.

Next set the service to start automatically. This can be done by typing Windows+R and typing in services.msc to run the Service Manager.

From the Service Manager find "Domain Connect DDDNS Update", right click, and select "Properties".

Click Start (to begin the service), and select "Automatic" as the Startup Type to have it start on boot.

=== Logging ===

Interesting events are logged to the Windows Event log.
